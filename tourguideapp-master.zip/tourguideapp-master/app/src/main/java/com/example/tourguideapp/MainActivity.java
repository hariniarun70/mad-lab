package com.example.tourguideapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnAttractions = findViewById(R.id.btnAttractions);
        Button btnRestaurants = findViewById(R.id.btnRestaurants);

        // Send "Attractions" category to next screen
        btnAttractions.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CategoryActivity.class);
            intent.putExtra("CATEGORY", "Attractions");
            startActivity(intent);
        });

        // Send "Restaurants" category to next screen
        btnRestaurants.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CategoryActivity.class);
            intent.putExtra("CATEGORY", "Restaurants");
            startActivity(intent);
        });
    }
}