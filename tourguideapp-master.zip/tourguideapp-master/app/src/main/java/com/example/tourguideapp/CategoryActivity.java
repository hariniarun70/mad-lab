package com.example.tourguideapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        TextView header = findViewById(R.id.txtHeader);
        ListView listView = findViewById(R.id.listPlaces);

        // Get the category name sent from MainActivity
        String category = getIntent().getStringExtra("CATEGORY");
        header.setText(category);

        String[] data;

        if (category != null && category.equals("Attractions")) {
            data = new String[]{"Central Park", "The Grand Palace", "Main Museum", "Liberty Square", "Old Town Bridge"};
        } else {
            data = new String[]{"Spicy Bistro", "The Italian Kitchen", "Seafood Wharf", "Veggie Delight", "Skyline Grill"};
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);
    }
}